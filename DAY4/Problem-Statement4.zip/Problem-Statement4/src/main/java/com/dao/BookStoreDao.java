package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.entity.LoginEntity;

import com.entity.RegisterEntity;


public class BookStoreDao {
	private Connection con;
	public BookStoreDao(Connection con) {
		super();
		this.con=con;
	}
	 public boolean userLogin(LoginEntity ul) {
		 boolean f=false;

		try {
			 String sql="select username,password from user where username=? and password= ?";
			 PreparedStatement ps=con.prepareStatement(sql);
			 ps.setString(1,ul.getUsername());
			 ps.setString(2,ul.getPassword());
			 ResultSet result=ps.executeQuery();
			f= result.next();
			 if(result.getRow()==1) {
				f=true;
			 }
			
		}catch(Exception e) {
			 e.printStackTrace();
		}
		return f;

		 
	 }
	 
	 public boolean userRegister(RegisterEntity re) {
		 boolean f=false;
		 try {
			 String sql="insert into user(name,username,address,password,email)values(?,?,?,?,?)";
			 PreparedStatement ps=con.prepareStatement(sql);
			 ps.setString(1,re.getFullname());
			 ps.setString(3,re.getAddress());
			 ps.setString(5,re.getEmail());
			 ps.setString(2,re.getUsername());
			 ps.setString(4,re.getPassword());
			
			 int result=ps.executeUpdate();
			 if(result==1) {
				 f=true;
			 }
			 
		 }catch(Exception e) {
			 e.printStackTrace();
		 }
		 return f;
	 }

}
