package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.BookStoreDao;

import com.db.DBConnection;
import com.entity.LoginEntity;
@WebServlet("/login")

/**
 * Servlet implementation class login
 */
public class login extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public login() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		try {
			String username=request.getParameter("username");
			String password=request.getParameter("password");
		

			BookStoreDao dao= new BookStoreDao (DBConnection.getCon());
			LoginEntity ul=new LoginEntity(username,password);

			boolean f=dao.userLogin(ul);

			HttpSession session=request.getSession();
			 response.setContentType("text/html");

			
			if(f) {
				session.setAttribute("success","Login Successfull");
				session.setAttribute("user",username);
				response.sendRedirect("welcome.jsp");
			
			}else {
				session.setAttribute("failed","Something went wrong");
				response.sendRedirect("login.jsp");
			}
			
		}catch(Exception e) {
			
		}
	}

}
