package com.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.BookStoreDao;
import com.db.DBConnection;
import com.entity.BuyNow;
import com.entity.RegisterEntity;

/**
 * Servlet implementation class buynow
 */
public class buynow extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public buynow() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		
		try {
			String book_name=request.getParameter("book_name");
			String author=request.getParameter("author");
			int price=Integer.parseInt(request.getParameter("price"));
			int qty=Integer.parseInt(request.getParameter("qty"));


			BookStoreDao dao= new BookStoreDao (DBConnection.getCon());
			BuyNow bn=new BuyNow(book_name,author,price,qty);

			boolean f=dao.buy(bn);

			HttpSession session=request.getSession();
			 response.setContentType("text/html");

			
			if(f) {
				session.setAttribute("success","Payment Done Successfull");
				
				response.sendRedirect("Payment.jsp");
			
			}else {
				session.setAttribute("failed","Something went wrong");
				response.sendRedirect("buynow.jsp");
			}
			
		}catch(Exception e) {
			
		}
	}

}
