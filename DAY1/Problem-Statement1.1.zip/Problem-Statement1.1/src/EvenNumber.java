import java.util.Scanner;

public class EvenNumber {
	

		  public static void main(String args[]) {

		System.out.println("Enter Number from User");
		Scanner sc=new Scanner(System.in);
		int n= sc.nextInt(); 
		System.out.print("Even Numbers from 1 to "+n+" are: ");

		for (int i = 1; i <= n; i++) {

		   //if number%2 == 0 

		   if (i % 2 == 0) {

		 System.out.print(i + " ");

		   }

		}

		  }

		}

