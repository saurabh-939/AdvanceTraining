package com.org;

import java.util.ArrayList;
import java.util.Scanner;

public class Student {
	public static void main(String args[]) {
		ArrayList<String> email = new ArrayList<String>();
	    email.add("saurabh");
	    email.add("shubham");
	    email.add("prasad");
	    email.add("umar");
	    email.add("prasenjeet");
	   
	  
	    Scanner sc =new Scanner(System.in);
	    System.out.println("Enter Student Name:");
	    String str= sc.nextLine(); //reads string.
	  
	    

	    for(int i=0; i<email.size();i++) {
	    	if(email.get(i).equals(str)) {
	    		System.out.println("Student Name found :"+email.get(i));
	    		break;
	    	}else {
	    		System.out.println("Student Name Not found");
	    		break;
	    	}
	    	
	    }

	    
	}

}
