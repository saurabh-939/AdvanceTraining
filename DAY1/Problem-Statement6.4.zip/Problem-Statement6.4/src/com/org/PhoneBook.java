package com.org;

import java.io.*;
import java.util.*;
 
public class PhoneBook {
	public static String msg=	"Press:   -  1  Add contact  -  2  Search  - 3  Exit :";
	public static void main(String[] args) {		
		System.out.println("*** Welcome to MyPhone Book ***");
		Scanner s=new Scanner(System.in);		
		for(;;){
				System.out.print(msg+"\n"+"Enter Your Choice:");
				int n=s.nextInt();			
 
				
				if (n==1){
					System.out.print("Type in contact details in the format: name,phone\n:");
					Scanner s1=new Scanner(System.in);
					Scanner s2=new Scanner(System.in);
					System.out.println("Enter Name");
					String name=s1.nextLine();	
					System.out.println("Enter Phone");
					String phone=s1.nextLine();	
					 HashMap<String, String> addcontact = new HashMap<String, String>();
					 addcontact.put(name, phone);
					System.out.println(addcontact);
					
 
				}else if (n==2){
					HashMap<String, Integer> contact = new HashMap<String, Integer>();
					contact.put("Saurabh", 123456);
					contact.put("Shubham", 543216);
					Scanner s3=new Scanner(System.in);
					System.out.println("Enter Name to be search:");
					String search=s3.nextLine();
					if(contact.containsKey(search))
					{
						System.out.println(contact);
					}
					else {
						System.out.println("does not exist");
					}
 
				}else if (n==3){
					System.out.println("Bye....");
					System.exit(0);
				}else{					
					System.out.print(" Try again \n:");
				}
 
		}
 
	}
 
}