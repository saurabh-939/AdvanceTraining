import java.util.Scanner;

public class IntArray {
	
	public static void partA() {
		  int [] arr = new int [] {3, 2, 4, 5, 6, 4, 5, 7, 3, 2, 3, 4, 7, 1, 2, 0, 0, 0};  
	        int sum = 0;  
	        System.out.println("Enter lenth upto "); 
	        Scanner sc=new Scanner(System.in);
	        int newlen=sc.nextInt();
	        for (int i = 0; i < newlen; i++) {  
	        	
	           sum = sum + arr[i];  
	        }  
	        System.out.println("Part A");
	        System.out.println("sum of elements from index 0 to 14:- " + sum);  
	        arr[15]=sum;
	        System.out.println("Sum stores it at element 15:- " + arr[15]);
	   
		
	}
	public static void partB() {
		  int [] arr = new int [] {3, 2, 4, 5, 6, 4, 5, 7, 3, 2, 3, 4, 7, 1, 2, 0, 0, 0};  
	        int sum = 0;  
	        
	       
	        for (int i = 0; i < arr.length; i++) {  
	        	
	           sum = sum + arr[i];  
	        }
	        System.out.println("Part B"); 
	        System.out.println("sum of elements from all index:- " + sum); 
	        arr[16]=sum;
	        System.out.println("Sum stores it at element 16:- " + arr[16]);
		
	}
	
	public static void partC() {
		  int [] arr = new int [] {3, 2, 4, 5, 6, 4, 5, 7, 3, 2, 3, 4, 7, 1, 2, 0, 0, 0};  
	     
		  int minValue = arr[0];
	        for (int i = 0; i < arr.length; i++) {  
	        	
	        	if (arr[i] < minValue)
	        		  
	                minValue = arr[i]; 
	        }
	        System.out.println("Part C"); 
	        System.out.println("Smallest element present in given array: "+ minValue); 
	        arr[17]=minValue;
	        System.out.println("Sum stores it at element 17:- " + arr[17]);
		
	}
	 
	 
	    public static void main(String[] args) {  
	    	
	    	partA();
	    	partB();
	        partC();
	    }  
	}  


