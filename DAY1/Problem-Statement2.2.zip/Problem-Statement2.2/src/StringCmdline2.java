import java.util.Scanner;

public class StringCmdline2 {

		  public static void main(String[] args) {
			System.out.println("Enter first number:");  
			Scanner sc=new Scanner(System.in);
			int firstNo =sc.nextInt();
			System.out.println("Enter second number:");  
			Scanner sc1=new Scanner(System.in);
			int secondNo=sc1.nextInt();
			
			System.out.println("Enter Number Upto print:");  
			Scanner sc2=new Scanner(System.in);
			int n =sc2.nextInt();
		 
		    System.out.print(firstNo  + ", ");
		    for (int i=1;i <= n;i++) {
		     

		      int nextNo =   firstNo + secondNo;
		      firstNo  = secondNo ;
		      secondNo = nextNo;

		    
		      System.out.print(nextNo  + ", ");
		    }
		  }
		}


