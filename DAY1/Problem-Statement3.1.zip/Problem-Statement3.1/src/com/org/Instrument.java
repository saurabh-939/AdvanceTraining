package com.org;

public abstract class Instrument {
	public abstract void play();
}