package com.org;

import java.util.Scanner;

public class InterChange {
	public static boolean interchange(String A, String B, String C)
	{
		
		if (A.length() == 0 && B.length() == 0 && C.length() == 0) {
			return true;
		}

		if (C.length() == 0) {
			return false;
		}


		boolean a = (A.length() != 0 && C.charAt(0) == A.charAt(0)) &&
				interchange(A.substring(1), B, C.substring(1));


		boolean b = (B.length() != 0 && C.charAt(0) == B.charAt(0)) &&
				interchange(A, B.substring(1), C.substring(1));

		return a || b;
	}

	public static void main(String[] args)
	{
		
		
		Scanner Sc=new Scanner(System.in);
		System.out.println("Enter The First String :");
		String A=Sc.nextLine();
		System.out.println("Enter The Second String :");
		String B=Sc.nextLine();
		System.out.println("Enter The Third String :");
		String C=Sc.nextLine();		
		

		if (interchange(A, B, C)) {
			System.out.print("Valid shuffle");
		}
		else {
			System.out.print("NOT a valid shuffle");
		}
	}

}
