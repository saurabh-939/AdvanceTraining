package com.org;

import java.util.Scanner;

public class ClimbingStairs {
	
	 static int stair(int n)
	    {
	        if (n <= 1)
	            return n;
	        return stair(n - 1) + stair(n - 2);
	    }
	 
	  
	    static int countWays(int s)
	    {
	        return stair(s + 1);
	    }
	 
	       public static void main(String args[]) {
	    
	    	Scanner scanner=new Scanner(System.in);
	    System.out.println("Enter the Number");
	    int n=scanner.nextInt();
	    
	    {
	        
	        System.out.println("Number of ways = " + countWays(n));
	    }
	}

}
