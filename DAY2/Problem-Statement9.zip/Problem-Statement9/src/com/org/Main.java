package com.org;

import java.util.HashMap;


public class Main {
		 
	    public static void main(String[] args) {
	 

	        int[] arr = 	{2, 2, 2, 4, 4, 4, 5, 5, 6, 8, 8, 9 };

	        HashMap<Integer, Integer> Map = resolve(arr);
	 
	        for(int value : Map.keySet())
	        {
	            System.out.println(value + " occurs " + Map.get(value)+ " times");
	        }
	 
	    }
	 
	    public static HashMap<Integer, Integer> resolve(int[] arr)
	    {
	        HashMap<Integer, Integer> Map = new HashMap<>();
	        for(int value : arr)
	        {
	            if(!Map.containsKey(value))
	            {
	                Map.put(value, 1);
	            }
	            else {
	                Map.put(value, Map.get(value)+1);
	            }
	        }   
	        return Map;
	    }



}
