package com.training;

import java.util.Scanner;

public class TestProduct {
public static void main(String[] args) {
	System.out.println("1.Add Product\n2.Find by Id\n3.Delete by Id\n4.Update by id\n5.Show All\n6.Find by Category"
			+ "\n7.Find by brand or model\n 8. Find by brand and model\n9.Find by brand or category or model");
	Scanner scan = new Scanner(System.in);
	ProductServiceImpl pro = new ProductServiceImpl();
	int choice=scan.nextInt();
	String name,catagory,brand,model;
	int id,price, quantity;
	scan.nextLine();
	switch(choice) {
	case 1: System.out.println("Add New Product");
	 		
			System.out.println("Enter  name of the product:");
			name=scan.nextLine();
			
			System.out.println("Enter price of the product:");
			price=scan.nextInt();
			scan.nextLine();
			
			System.out.println("Enter quantity of the product:");
			quantity=scan.nextInt();
			scan.nextLine();
			
			System.out.println("Enter  catagory of the product:");
			catagory=scan.nextLine();
			
			System.out.println("Enter brand of the product:");
			brand=scan.nextLine();
			
			System.out.println("Enter  model of the product:");
			model=scan.nextLine();
			
			pro.insertProduct(name, price, quantity, catagory, brand, model);
			
			break;
			
	case 2:  System.out.println("Find By Id");
	
			System.out.println("Enter  ID of the product to be found:");
			id=scan.nextInt();
			scan.nextLine();
			pro.searchById(id);
			break;
	
			
	case 3: System.out.println("Delete By Id");
	
			System.out.println("Enter  product id to be deleted:");
			id=scan.nextInt();
			scan.nextLine();
			pro.deleteById(id);
			break;
			
	case 4:System.out.println("Update By Id");
	
	
			System.out.println("Enter  product id to be updated:");
			id=scan.nextInt();
			scan.nextLine();
			System.out.println("Enter  name of the product:");
			name=scan.nextLine();
			
			System.out.println("Enter  price of the product:");
			price=scan.nextInt();
			scan.nextLine();
			
			System.out.println("Enter  quantity of the product:");
			quantity=scan.nextInt();
			scan.nextLine();
			
			System.out.println("Enter  catagory of the product:");
			catagory=scan.nextLine();
			
			System.out.println("Enter  brand of the product:");
			brand=scan.nextLine();
			
			System.out.println("Enter model of the product:");
			model=scan.nextLine();
			pro.updateById(id, name, price, quantity, catagory, brand, model);
			break;
			
	case 5:System.out.println("Display all");
	
			pro.displayAll();
			break;
	case 6: System.out.println("Find by category");
	
			System.out.println("Enter  catagory of the product:");
			catagory=scan.nextLine();
			pro.byCatagory(catagory);
			break;
	
	case 7: System.out.println("Find by brand or model");
	
			System.out.println("Enter  brand of the product:");
			brand=scan.nextLine();
	
			System.out.println("Enter model of the product:");
			model=scan.nextLine();
			
			pro.byBrandOrModel(brand, model);
			break;
			
	case 8: System.out.println("Find by brand and model");
	
			System.out.println("Enter brand of the product:");
			brand=scan.nextLine();

			System.out.println("Enter  model of the product:");
			model=scan.nextLine();
	
			pro.byBrandAndModel(brand, model);
			break;
			
			
	case 9:System.out.println("Find by brand or category or model");
	
			System.out.println("Enter  brand of the product:");
			brand=scan.nextLine();

			System.out.println("Enter  model of the product:");
			model=scan.nextLine();
			
			System.out.println("Enter  catagory of the product:");
			catagory=scan.nextLine();
			
			pro.byBrandOrModelOrCategory(brand, model, model);
			break;
			
	
	}
}
}
